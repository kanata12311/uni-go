package com.unigo.tool;

import com.unigo.model.POI;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class POITool implements Tool {
    @Override
    public String getName() { return "search_poi"; }
    
    @Override
    public String getDescription() { return "根据城市、类别搜索景点/餐厅/酒店，参数: {city, category(可选)}"; }
    
    @Override
    public Object apply(Map<String, Object> params) {
        String city = params.getOrDefault("city", "成都").toString();
        List<POI> pois = new ArrayList<>();
        
        if (city.contains("成都")) {
            pois.add(POI.builder()
                    .id("p1").name("武侯祠").category("景点").address("成都市武侯祠大街231号")
                    .lat(30.6424).lng(104.0474).rating(4.7).price(50).openHours("08:00-18:00")
                    .indoor(false).tags("历史,三国文化").build());
            pois.add(POI.builder()
                    .id("p2").name("锦里古街").category("景点").address("成都市武侯祠大街")
                    .lat(30.6450).lng(104.0490).rating(4.5).price(0).openHours("全天")
                    .indoor(false).tags("古街,美食,夜景").build());
            pois.add(POI.builder()
                    .id("p3").name("成都大熊猫繁育研究基地").category("景点").address("成都市熊猫大道1375号")
                    .lat(30.7333).lng(104.1500).rating(4.8).price(55).openHours("07:30-18:00")
                    .indoor(false).tags("自然,亲子,熊猫").build());
            pois.add(POI.builder()
                    .id("p4").name("成都博物馆").category("景点").address("成都市小河街1号")
                    .lat(30.6570).lng(104.0620).rating(4.6).price(0).openHours("09:00-17:00")
                    .indoor(true).tags("历史,人文,室内").build());
            pois.add(POI.builder()
                    .id("p5").name("春熙路/太古里").category("景点").address("成都市锦江区")
                    .lat(30.6550).lng(104.0820).rating(4.5).price(0).openHours("全天")
                    .indoor(true).tags("购物,时尚,美食").build());
            pois.add(POI.builder()
                    .id("r1").name("建设巷小吃街").category("餐厅").address("成都市成华区建设巷")
                    .lat(30.6750).lng(104.1050).rating(4.5).price(45).openHours("10:00-22:00")
                    .indoor(false).tags("小吃,夜市,高性价比").build());
            pois.add(POI.builder()
                    .id("h1").name("青年旅舍(春熙路店)").category("酒店").address("成都市锦江区")
                    .lat(30.6540).lng(104.0810).rating(4.3).price(120).openHours("全天")
                    .indoor(true).tags("青旅,交通便利,经济").build());
        }
        return pois;
    }
}
