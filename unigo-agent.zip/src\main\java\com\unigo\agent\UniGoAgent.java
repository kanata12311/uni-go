package com.unigo.agent;

import com.unigo.agent.state.AgentState;
import com.unigo.model.*;
import com.unigo.planner.ItineraryPlanner;
import com.unigo.tool.Tool;
import com.unigo.memory.ShortTermMemory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
public class UniGoAgent {
    private final List<Tool> tools;
    private final ItineraryPlanner planner;
    private final ShortTermMemory memory;
    private final LLMService llmService;
    
    @Value("${unigo.agent.max-iterations:10}")
    private int maxIterations;
    
    public UniGoAgent(List<Tool> tools, ItineraryPlanner planner, 
                      ShortTermMemory memory, LLMService llmService) {
        this.tools = tools;
        this.planner = planner;
        this.memory = memory;
        this.llmService = llmService;
    }
    
    public Itinerary execute(TravelRequest request) {
        log.info("[UniGoAgent] 开始处理请求，用户={}, 目的地={}", request.getUserId(), request.getDestination());
        memory.initSession(request.getUserId());
        AgentState state = new AgentState();
        
        // 阶段1: 意图澄清与上下文构建（假设已多轮引导完成）
        Map<String, Object> context = new HashMap<>();
        context.put("request", request);
        context.put("destination", request.getDestination());
        context.put("budget", request.getBudget());
        context.put("days", calculateDays(request));
        context.put("preferences", request.getPreferences());
        
        // 阶段2-3: ReAct 长链推理闭环
        String systemPrompt = buildSystemPrompt(request);
        StringBuilder history = new StringBuilder();
        String toolDesc = buildToolDescriptions();
        
        while (state.getIteration() < maxIterations && !state.isFinished()) {
            state.setIteration(state.getIteration() + 1);
            String llmOutput = llmService.reactPrompt(systemPrompt, history.toString(), toolDesc);
            log.debug("[ReAct] Step {}: {}", state.getIteration(), llmOutput);
            
            String thought = extractTag(llmOutput, "Thought");
            String actionStr = extractTag(llmOutput, "Action");
            state.getThoughts().add(thought);
            state.getActions().add(actionStr);
            history.append("Thought: ").append(thought).append("\n");
            history.append("Action: ").append(actionStr).append("\n");
            
            if (actionStr.startsWith("finish")) {
                state.setFinished(true);
                state.setFinalAnswer("推理完成，准备生成行程");
                log.info("[UniGoAgent] ReAct 推理结束，共 {} 步", state.getIteration());
            } else {
                String observation = executeAction(actionStr, context);
                state.getObservations().add(observation);
                history.append("Observation: ").append(observation).append("\n");
            }
        }
        
        // 阶段4: 多约束融合与行程生成
        Itinerary itinerary = planner.plan(request, context);
        
        // 一致性校验（避免闭馆、绕路等逻辑幻觉）
        boolean valid = validateItinerary(itinerary, request);
        itinerary.setConsistent(valid);
        
        // 阶段5: 记忆更新（短期记忆）
        memory.update(request.getUserId(), itinerary);
        log.info("[UniGoAgent] 行程生成完毕，一致性校验={}, 预算符合率={}%", 
                valid, itinerary.getBudget() != null ? String.format("%.1f", itinerary.getBudget().getComplianceRate()) : 0);
        return itinerary;
    }
    
    private String executeAction(String action, Map<String, Object> context) {
        int parenIdx = action.indexOf('(');
        if (parenIdx < 0) return "Invalid action format";
        String toolName = action.substring(0, parenIdx).trim();
        String argsStr = action.substring(parenIdx + 1, action.lastIndexOf(')')).trim();
        
        for (Tool tool : tools) {
            if (tool.getName().equals(toolName)) {
                try {
                    Map<String, Object> params = parseArgs(argsStr);
                    Object result = tool.apply(params);
                    context.put(toolName + "_result", result);
                    return result != null ? result.toString() : "null";
                } catch (Exception e) {
                    log.error("工具调用失败: {}", toolName, e);
                    return "Error: " + e.getMessage();
                }
            }
        }
        return "Tool not found: " + toolName;
    }
    
    private Map<String, Object> parseArgs(String argsStr) {
        Map<String, Object> map = new HashMap<>();
        if (argsStr == null || argsStr.isEmpty() || argsStr.equals("{}")) return map;
        String clean = argsStr.replace("{", "").replace("}", "").replace("\"", "");
        for (String pair : clean.split(",")) {
            String[] kv = pair.split(":", 2);
            if (kv.length == 2) {
                String key = kv[0].trim();
                String val = kv[1].trim();
                try {
                    map.put(key, Integer.parseInt(val));
                } catch (NumberFormatException e1) {
                    try {
                        map.put(key, Double.parseDouble(val));
                    } catch (NumberFormatException e2) {
                        map.put(key, val);
                    }
                }
            }
        }
        return map;
    }
    
    private String extractTag(String text, String tag) {
        String prefix = tag + ":";
        int start = text.indexOf(prefix);
        if (start < 0) return "";
        int end = text.indexOf("\n", start);
        if (end < 0) end = text.length();
        return text.substring(start + prefix.length(), end).trim();
    }
    
    private String buildSystemPrompt(TravelRequest req) {
        return "你是 UniGo 旅游规划 Agent，采用 ReAct 模式工作。\n" +
               "每次输出必须严格包含两行：\n" +
               "Thought: 你对当前状态的思考\n" +
               "Action: 你要执行的动作，格式为 toolName({JSON参数}) 或 finish({})\n" +
               "当前用户需求：去" + req.getDestination() + "，预算" + req.getBudget() + "元，偏好：" + req.getPreferences() + "。";
    }
    
    private String buildToolDescriptions() {
        StringBuilder sb = new StringBuilder();
        for (Tool tool : tools) {
            sb.append("- ").append(tool.getName()).append(": ").append(tool.getDescription()).append("\n");
        }
        return sb.toString();
    }
    
    private int calculateDays(TravelRequest req) {
        if (req.getStartDate() != null && req.getEndDate() != null) {
            return (int) (req.getEndDate().toEpochDay() - req.getStartDate().toEpochDay()) + 1;
        }
        return 2;
    }
    
    private boolean validateItinerary(Itinerary it, TravelRequest req) {
        if (it == null || it.getDays() == null) return false;
        if (it.getBudget() != null && it.getBudget().getRemaining() < -50) {
            log.warn("预算超支校验未通过: remaining={}", it.getBudget().getRemaining());
            return false;
        }
        for (DayPlan day : it.getDays()) {
            if (day.getActivities() == null) continue;
            // 可扩展：校验时间冲突、闭馆时间、地理可达性
        }
        return true;
    }
}
