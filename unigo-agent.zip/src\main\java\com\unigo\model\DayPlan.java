package com.unigo.model;

import lombok.Data;
import lombok.Builder;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
public class DayPlan {
    private LocalDate date;
    private String weather;
    private List<Activity> activities;
    private double dailyCost;
}
