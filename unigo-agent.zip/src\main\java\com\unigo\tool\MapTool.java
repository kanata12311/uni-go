package com.unigo.tool;

import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class MapTool implements Tool {
    @Override
    public String getName() { return "get_distance"; }
    
    @Override
    public String getDescription() { return "计算两地交通距离与预估费用，参数: {from_lat, from_lng, to_lat, to_lng}"; }
    
    @Override
    public Object apply(Map<String, Object> params) {
        double lat1 = Double.parseDouble(params.getOrDefault("from_lat", "30.64").toString());
        double lng1 = Double.parseDouble(params.getOrDefault("from_lng", "104.04").toString());
        double lat2 = Double.parseDouble(params.getOrDefault("to_lat", "30.65").toString());
        double lng2 = Double.parseDouble(params.getOrDefault("to_lng", "104.06").toString());
        
        double dist = Math.abs(lat1 - lat2) + Math.abs(lng1 - lng2);
        double cost = Math.round(dist * 100 + 10);
        return Map.of("distance_km", String.format("%.2f", dist * 100), "transport_cost", cost);
    }
}
