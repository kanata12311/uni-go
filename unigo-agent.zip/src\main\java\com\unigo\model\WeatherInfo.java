package com.unigo.model;

import lombok.Data;
import lombok.Builder;
import java.time.LocalDate;

@Data
@Builder
public class WeatherInfo {
    private LocalDate date;
    private String condition;
    private int temperature;
    private String suggestion;
}
