package com.unigo.controller;

import com.unigo.model.Itinerary;
import com.unigo.model.TravelRequest;
import com.unigo.service.TravelService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/travel")
public class TravelController {
    private final TravelService travelService;
    
    public TravelController(TravelService travelService) {
        this.travelService = travelService;
    }
    
    @PostMapping("/plan")
    public Itinerary plan(@RequestBody TravelRequest request) {
        return travelService.planTrip(request);
    }
}
