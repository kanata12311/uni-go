package com.unigo.planner;

import com.unigo.model.*;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class ItineraryPlanner {
    
    public Itinerary plan(TravelRequest request, Map<String, Object> context) {
        String destination = request.getDestination();
        int days = (int) context.getOrDefault("days", 2);
        double budget = (double) context.getOrDefault("budget", 500.0);
        
        @SuppressWarnings("unchecked")
        List<POI> allPois = (List<POI>) context.getOrDefault("search_poi_result", new ArrayList<POI>());
        Budget budgetResult = (Budget) context.getOrDefault("estimate_budget_result", 
                Budget.builder().total(budget).remaining(budget).complianceRate(100).build());
        WeatherInfo weather = (WeatherInfo) context.getOrDefault("get_weather_result", null);
        
        // 多约束融合：过滤过高消费，按评分降序
        List<POI> candidates = allPois.stream()
                .filter(p -> !"酒店".equals(p.getCategory()))
                .filter(p -> p.getPrice() <= budget / 2)
                .sorted(Comparator.comparingDouble(POI::getRating).reversed())
                .collect(Collectors.toList());
        
        // 启发式调整：若雨天优先室内（本示例为多云，仅作逻辑展示）
        if (weather != null && "RAINY".equals(weather.getCondition())) {
            candidates.sort((a, b) -> Boolean.compare(b.isIndoor(), a.isIndoor()));
        }
        
        String weatherAdvice = weather != null ? weather.getSuggestion() : "";
        List<DayPlan> dayPlans = new ArrayList<>();
        LocalDate currentDate = request.getStartDate() != null ? request.getStartDate() : LocalDate.now().plusDays(1);
        
        int poiIndex = 0;
        for (int d = 0; d < days; d++) {
            List<Activity> activities = new ArrayList<>();
            double dailyCost = 0;
            LocalTime currentTime = LocalTime.of(9, 0);
            
            // 上午：景点A
            if (poiIndex < candidates.size()) {
                POI poi = candidates.get(poiIndex++);
                activities.add(buildActivity(currentTime, poi, "VISIT", 150));
                dailyCost += poi.getPrice();
                currentTime = currentTime.plusMinutes(150 + 30); // 游览+交通
            }
            
            // 午餐
            POI meal = findMealPoi(allPois);
            if (meal != null) {
                activities.add(buildActivity(currentTime, meal, "MEAL", 60));
                dailyCost += meal.getPrice();
                currentTime = currentTime.plusMinutes(60 + 30);
            }
            
            // 下午：景点B
            if (poiIndex < candidates.size()) {
                POI poi = candidates.get(poiIndex++);
                activities.add(buildActivity(currentTime, poi, "VISIT", 150));
                dailyCost += poi.getPrice();
                currentTime = currentTime.plusMinutes(150 + 30);
            }
            
            // 晚餐（简化：复用餐厅）
            if (meal != null) {
                activities.add(buildActivity(currentTime, meal, "MEAL", 60));
                dailyCost += meal.getPrice();
            }
            
            // 交通预估（每次转场约15元）
            int transfers = Math.max(0, activities.size() - 1);
            dailyCost += transfers * 15;
            
            dayPlans.add(DayPlan.builder()
                    .date(currentDate.plusDays(d))
                    .weather(weather != null ? weather.getCondition() : "UNKNOWN")
                    .activities(activities)
                    .dailyCost(dailyCost)
                    .build());
        }
        
        return Itinerary.builder()
                .destination(destination)
                .days(dayPlans)
                .budget(budgetResult)
                .weatherAdvice(weatherAdvice)
                .summary(generateSummary(dayPlans, budgetResult))
                .build();
    }
    
    private Activity buildActivity(LocalTime start, POI poi, String type, int durationMinutes) {
        return Activity.builder()
                .startTime(start)
                .endTime(start.plusMinutes(durationMinutes))
                .poi(poi)
                .type(type)
                .cost(poi.getPrice())
                .transportMode("地铁/公交")
                .notes("")
                .build();
    }
    
    private POI findMealPoi(List<POI> pois) {
        return pois.stream()
                .filter(p -> "餐厅".equals(p.getCategory()))
                .findFirst()
                .orElse(null);
    }
    
    private String generateSummary(List<DayPlan> days, Budget budget) {
        int totalActivities = days.stream().mapToInt(d -> d.getActivities().size()).sum();
        return String.format("共规划 %d 天，包含 %d 个活动，预计总花费 %.0f 元，预算符合率 %.0f%%",
                days.size(), totalActivities, 
                budget.getTotal() - budget.getRemaining(), 
                budget.getComplianceRate());
    }
}
