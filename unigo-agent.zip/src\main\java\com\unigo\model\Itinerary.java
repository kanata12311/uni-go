package com.unigo.model;

import lombok.Data;
import lombok.Builder;
import java.util.List;

@Data
@Builder
public class Itinerary {
    private String destination;
    private List<DayPlan> days;
    private Budget budget;
    private String weatherAdvice;
    private String summary;
    private boolean consistent;
}
