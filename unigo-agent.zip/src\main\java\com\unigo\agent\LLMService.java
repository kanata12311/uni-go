package com.unigo.agent;

public interface LLMService {
    String reactPrompt(String systemPrompt, String history, String availableTools);
}
