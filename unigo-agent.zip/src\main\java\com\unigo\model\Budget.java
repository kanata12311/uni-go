package com.unigo.model;

import lombok.Data;
import lombok.Builder;

@Data
@Builder
public class Budget {
    private double total;
    private double accommodation;
    private double transport;
    private double food;
    private double tickets;
    private double remaining;
    private double complianceRate;
}
