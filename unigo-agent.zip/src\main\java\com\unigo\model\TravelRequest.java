package com.unigo.model;

import lombok.Data;
import java.time.LocalDate;
import java.util.Map;

@Data
public class TravelRequest {
    private String userId;
    private String destination;
    private LocalDate startDate;
    private LocalDate endDate;
    private Double budget;
    private String preferences;
    private Map<String, Object> context;
}
