package com.unigo.tool;

import java.util.Map;

public interface Tool {
    String getName();
    String getDescription();
    Object apply(Map<String, Object> params);
}
