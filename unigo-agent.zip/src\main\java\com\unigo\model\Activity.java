package com.unigo.model;

import lombok.Data;
import lombok.Builder;
import java.time.LocalTime;

@Data
@Builder
public class Activity {
    private LocalTime startTime;
    private LocalTime endTime;
    private POI poi;
    private String type;
    private double cost;
    private String transportMode;
    private String notes;
}
