package com.unigo.rag;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RAGService {
    
    @Value("${unigo.rag.top-k:3}")
    private int topK;
    
    public List<String> retrieve(String query) {
        // 模拟向量检索，实际可接入 Spring AI VectorStore (Redis/Milvus/PGVector)
        if (query.contains("成都")) {
            return List.of(
                    "经验1：成都地铁覆盖主要景点，建议购买天府通交通卡或使用手机乘车码。",
                    "经验2：大熊猫繁育基地需早上8点前到达，否则排队严重且熊猫会进入睡眠。",
                    "经验3：锦里夜景优于白天，建议傍晚前往并与武侯祠安排在同一天。"
            );
        }
        return List.of("暂无相关经验贴士，建议参考官方旅游指南。");
    }
}
