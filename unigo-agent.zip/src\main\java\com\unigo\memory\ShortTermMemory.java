package com.unigo.memory;

import com.unigo.model.Itinerary;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ShortTermMemory {
    private final Map<String, Itinerary> userMemory = new ConcurrentHashMap<>();
    
    public void initSession(String userId) {
        // 可在此加载用户画像或历史行程
    }
    
    public void update(String userId, Itinerary itinerary) {
        userMemory.put(userId, itinerary);
    }
    
    public Itinerary getLastItinerary(String userId) {
        return userMemory.get(userId);
    }
    
    public void clear(String userId) {
        userMemory.remove(userId);
    }
}
