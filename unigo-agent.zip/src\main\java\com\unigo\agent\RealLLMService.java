package com.unigo.agent;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "unigo.agent.mock-mode", havingValue = "false", matchIfMissing = false)
public class RealLLMService implements LLMService {
    private final ChatClient chatClient;
    
    public RealLLMService(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }
    
    @Override
    public String reactPrompt(String systemPrompt, String history, String availableTools) {
        String fullPrompt = systemPrompt + "\n\n可用工具:\n" + availableTools + "\n\n历史记录:\n" + history + "\n\n请根据以上信息，输出下一步的 Thought 和 Action（严格格式：Thought: xxx\nAction: xxx）:";
        return chatClient.prompt()
                .user(fullPrompt)
                .call()
                .content();
    }
}
