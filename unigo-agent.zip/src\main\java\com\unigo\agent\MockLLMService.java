package com.unigo.agent;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "unigo.agent.mock-mode", havingValue = "true")
public class MockLLMService implements LLMService {
    private int step = 0;
    
    @Override
    public String reactPrompt(String systemPrompt, String history, String availableTools) {
        step++;
        if (history.isEmpty()) {
            return "Thought: 用户想去成都过周末，预算500元。我需要先获取天气情况，以便决定室内或室外景点优先级。\nAction: get_weather({\"city\":\"成都\"})";
        }
        if (step == 2) {
            return "Thought: 天气多云舒适，适合户外。现在我需要搜索成都的高性价比景点和餐厅，控制预算在500以内。\nAction: search_poi({\"city\":\"成都\",\"category\":\"景点\"})";
        }
        if (step == 3) {
            return "Thought: 已获得景点和餐厅列表。接下来需要进行预算估算，确认500元预算是否足够覆盖住宿、餐饮、交通和门票。\nAction: estimate_budget({\"days\":2,\"budget\":500})";
        }
        return "Thought: 所有信息已收集完毕，预算在可控范围内，现在可以结束工具调用，进入行程生成阶段。\nAction: finish({\"status\":\"ok\"})";
    }
}
