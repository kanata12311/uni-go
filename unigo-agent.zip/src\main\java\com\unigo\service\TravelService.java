package com.unigo.service;

import com.unigo.agent.UniGoAgent;
import com.unigo.model.Itinerary;
import com.unigo.model.TravelRequest;
import com.unigo.rag.RAGService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TravelService {
    private final UniGoAgent agent;
    private final RAGService ragService;
    
    public TravelService(UniGoAgent agent, RAGService ragService) {
        this.agent = agent;
        this.ragService = ragService;
    }
    
    public Itinerary planTrip(TravelRequest request) {
        // 阶段1-4：Agent 长链推理 + 工具编排 + 规划 + 校验
        Itinerary itinerary = agent.execute(request);
        
        // 阶段5：RAG 增强（松耦合，独立运行）
        List<String> tips = ragService.retrieve(request.getDestination() + " " + request.getPreferences());
        if (itinerary != null && !tips.isEmpty()) {
            String existing = itinerary.getSummary() != null ? itinerary.getSummary() : "";
            itinerary.setSummary(existing + "\n【驴友经验】\n" + String.join("\n", tips));
        }
        
        return itinerary;
    }
}
