package com.unigo.tool;

import com.unigo.model.Budget;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class BudgetTool implements Tool {
    @Override
    public String getName() { return "estimate_budget"; }
    
    @Override
    public String getDescription() { return "预估整体预算分配，参数: {days, budget}"; }
    
    @Override
    public Object apply(Map<String, Object> params) {
        int days = Integer.parseInt(params.getOrDefault("days", 2).toString());
        double total = Double.parseDouble(params.getOrDefault("budget", 500.0).toString());
        
        double accommodation = days * 110;
        double food = days * 90;
        double transport = days * 40;
        double tickets = 105;
        
        double sum = accommodation + food + transport + tickets;
        double remaining = total - sum;
        double compliance = total > 0 ? Math.min(100, (total / Math.max(sum, 1)) * 100) : 0;
        
        return Budget.builder()
                .total(total)
                .accommodation(accommodation)
                .food(food)
                .transport(transport)
                .tickets(tickets)
                .remaining(remaining)
                .complianceRate(compliance)
                .build();
    }
}
