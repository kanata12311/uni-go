package com.unigo.model;

import lombok.Data;
import lombok.Builder;

@Data
@Builder
public class POI {
    private String id;
    private String name;
    private String category;
    private String address;
    private double lat;
    private double lng;
    private double rating;
    private double price;
    private String openHours;
    private boolean indoor;
    private String tags;
}
