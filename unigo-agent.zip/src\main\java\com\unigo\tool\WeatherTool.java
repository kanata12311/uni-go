package com.unigo.tool;

import com.unigo.model.WeatherInfo;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.util.Map;

@Component
public class WeatherTool implements Tool {
    @Override
    public String getName() { return "get_weather"; }
    
    @Override
    public String getDescription() { return "获取指定城市未来几天的天气预报与出行建议，参数: {city}" ; }
    
    @Override
    public Object apply(Map<String, Object> params) {
        String city = params.getOrDefault("city", "成都").toString();
        return WeatherInfo.builder()
                .date(LocalDate.now().plusDays(1))
                .condition("CLOUDY")
                .temperature(22)
                .suggestion(city + " 近期天气多云，气温舒适，适合户外游览，建议备一件薄外套。若遇雨天可优先安排室内景点如博物馆。")
                .build();
    }
}
