package com.unigo.agent.state;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

@Data
public class AgentState {
    private int iteration = 0;
    private List<String> thoughts = new ArrayList<>();
    private List<String> actions = new ArrayList<>();
    private List<String> observations = new ArrayList<>();
    private boolean finished = false;
    private String finalAnswer;
}
